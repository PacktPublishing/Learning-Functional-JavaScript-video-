# Run tests

```sh
npm install
npm test
```
