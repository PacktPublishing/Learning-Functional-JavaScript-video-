exports.node = {
  environment: 'node',
  tests: ['test/**/*.js']
};
